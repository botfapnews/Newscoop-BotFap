newscoop-legacy-plugins
=======================

Legacy plugins for Newscoop - depreceated from 4.3
