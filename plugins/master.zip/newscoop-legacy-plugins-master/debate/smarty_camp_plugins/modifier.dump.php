<?php
function smarty_modifier_dump($p_input)
{
    var_dump($p_input);
}