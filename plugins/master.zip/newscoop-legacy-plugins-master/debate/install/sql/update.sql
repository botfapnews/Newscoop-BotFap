ALTER TABLE `plugin_debate` ADD `reset_token` varchar(40) NOT NULL DEFAULT '';
