ALTER TABLE `plugin_poll` ADD `reset_token` varchar(40) NOT NULL DEFAULT '';
